
import React, { useState } from 'react';
import { 
  Plus, 
  FlaskConical, 
  Settings2, 
  RefreshCw,
  Trash2,
  GraduationCap,
  BarChart3,
  CheckCircle2,
  AlertTriangle,
  Info
} from 'lucide-react';
import { Compound, OptimizationResult } from './types';
import { PolyherbalOptimizer } from './services/optimizer';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  ScatterChart,
  Scatter,
  ZAxis
} from 'recharts';

const INITIAL_COMPOUNDS: Compound[] = [
  {
    id: '1',
    name: 'Curcumin',
    mw: 368.38,
    logP: 3.2,
    tpsa: 93.1,
    hbd: 2,
    hba: 6,
    bindingAffinity: -8.4,
    rasa: 'Tikta',
    guna: 'Ruksha',
    virya: 'Ushna',
    vipaka: 'Katu'
  },
  {
    id: '2',
    name: 'Piperine',
    mw: 285.34,
    logP: 3.6,
    tpsa: 38.3,
    hbd: 0,
    hba: 3,
    bindingAffinity: -7.1,
    rasa: 'Katu',
    guna: 'Laghu',
    virya: 'Ushna',
    vipaka: 'Katu'
  }
];

export default function App() {
  const [compounds, setCompounds] = useState<Compound[]>(INITIAL_COMPOUNDS);
  const [optimizing, setOptimizing] = useState(false);
  const [result, setResult] = useState<OptimizationResult | null>(null);
  const [weights, setWeights] = useState({ efficacy: 0.5, synergy: 0.3, toxicity: 0.2 });

  const addCompound = () => {
    if (compounds.length >= 5) return;
    const newId = Date.now().toString();
    setCompounds([...compounds, {
      id: newId,
      name: `Herb ${compounds.length + 1}`,
      mw: 300,
      logP: 2.5,
      tpsa: 50,
      hbd: 1,
      hba: 4,
      bindingAffinity: -5.0,
      rasa: 'Madhura',
      guna: 'Snigdha',
      virya: 'Sheeta',
      vipaka: 'Madhura'
    }]);
  };

  const removeCompound = (id: string) => {
    if (compounds.length <= 2) return;
    setCompounds(compounds.filter(c => c.id !== id));
  };

  const updateCompound = (id: string, field: keyof Compound, value: any) => {
    setCompounds(compounds.map(c => c.id === id ? { ...c, [field]: value } : c));
  };

  const handleOptimize = async () => {
    setOptimizing(true);
    setResult(null);
    try {
      const optimizer = new PolyherbalOptimizer(compounds, weights);
      const res = await optimizer.runOptimization();
      setResult(res);
    } catch (error) {
      console.error("Optimization failed:", error);
      alert("Error during optimization. Check your API key and network connection.");
    } finally {
      setOptimizing(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2 rounded-xl shadow-lg shadow-indigo-200">
            <GraduationCap className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">APMOE</h1>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">AI Polyherbal Optimizer</p>
          </div>
        </div>
        <button 
          onClick={handleOptimize}
          disabled={optimizing || compounds.length < 2}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-full font-bold transition-all shadow-md ${
            optimizing 
              ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
              : 'bg-indigo-600 text-white hover:bg-indigo-700 active:scale-95'
          }`}
        >
          {optimizing ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              Evolving Ratios...
            </>
          ) : (
            <>
              <FlaskConical className="w-5 h-5" />
              Optimize Formulation
            </>
          )}
        </button>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Inputs */}
        <div className="lg:col-span-4 space-y-6">
          <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-6">
            <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-6">
              <Settings2 className="w-4 h-4 text-indigo-500" />
              OBJECTIVE WEIGHTS
            </h2>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Therapeutic Efficacy</label>
                  <span className="text-xs font-bold text-indigo-600">{(weights.efficacy * 100).toFixed(0)}%</span>
                </div>
                <input 
                  type="range" min="0" max="1" step="0.1" 
                  value={weights.efficacy}
                  onChange={(e) => setWeights({ ...weights, efficacy: parseFloat(e.target.value) })}
                  className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                />
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Molecular Synergy</label>
                  <span className="text-xs font-bold text-emerald-600">{(weights.synergy * 100).toFixed(0)}%</span>
                </div>
                <input 
                  type="range" min="0" max="1" step="0.1" 
                  value={weights.synergy}
                  onChange={(e) => setWeights({ ...weights, synergy: parseFloat(e.target.value) })}
                  className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                />
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Toxicity Mitigation</label>
                  <span className="text-xs font-bold text-rose-600">{(weights.toxicity * 100).toFixed(0)}%</span>
                </div>
                <input 
                  type="range" min="0" max="1" step="0.1" 
                  value={weights.toxicity}
                  onChange={(e) => setWeights({ ...weights, toxicity: parseFloat(e.target.value) })}
                  className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-rose-600"
                />
              </div>
            </div>
          </section>

          <section className="bg-white rounded-3xl shadow-sm border border-slate-200 p-6 flex flex-col max-h-[700px]">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                <Plus className="w-4 h-4 text-indigo-500" />
                PHYTOCHEMICAL LIBRARY
              </h2>
              <button 
                onClick={addCompound}
                disabled={compounds.length >= 5}
                className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full text-xs font-bold hover:bg-indigo-100 disabled:opacity-50"
              >
                + Add Herb
              </button>
            </div>
            
            <div className="space-y-4 overflow-y-auto pr-2 custom-scrollbar">
              {compounds.map((c) => (
                <div key={c.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-100 group transition-all hover:bg-white hover:shadow-md hover:border-indigo-100">
                  <div className="flex justify-between items-start mb-3">
                    <input 
                      className="bg-transparent font-bold text-slate-800 outline-none focus:text-indigo-600 transition-colors w-full"
                      value={c.name}
                      onChange={(e) => updateCompound(c.id, 'name', e.target.value)}
                    />
                    <button 
                      onClick={() => removeCompound(c.id)}
                      className="p-1 text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 font-bold uppercase">Affinity</label>
                      <input 
                        type="number" step="0.1"
                        className="w-full text-xs p-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-100 outline-none"
                        value={c.bindingAffinity}
                        onChange={(e) => updateCompound(c.id, 'bindingAffinity', parseFloat(e.target.value))}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 font-bold uppercase">Virya</label>
                      <select 
                        className="w-full text-xs p-2 bg-white border border-slate-200 rounded-xl outline-none"
                        value={c.virya}
                        onChange={(e) => updateCompound(c.id, 'virya', e.target.value)}
                      >
                        <option value="Ushna">Ushna</option>
                        <option value="Sheeta">Sheeta</option>
                      </select>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Right Column: Dashboard */}
        <div className="lg:col-span-8 space-y-6">
          {!result && !optimizing && (
            <div className="h-full min-h-[500px] flex flex-col items-center justify-center bg-white rounded-[40px] border-2 border-dashed border-slate-200 text-slate-400 p-12 text-center">
              <div className="bg-indigo-50 p-8 rounded-full mb-8 animate-bounce">
                <FlaskConical className="w-16 h-16 text-indigo-200" />
              </div>
              <h3 className="text-2xl font-bold text-slate-700 mb-3">Ready for Analysis</h3>
              <p className="max-w-md mx-auto text-slate-500 text-lg">
                The APMOE engine is on standby. Add your herbal compounds and click "Optimize Formulation" to generate a research-grade synergy report.
              </p>
            </div>
          )}

          {optimizing && (
            <div className="h-full min-h-[500px] flex flex-col items-center justify-center bg-white rounded-[40px] border border-slate-200 p-12 text-center shadow-xl">
              <div className="relative mb-10">
                <div className="w-32 h-32 border-8 border-indigo-50 border-t-indigo-600 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <RefreshCw className="w-12 h-12 text-indigo-500 animate-pulse" />
                </div>
              </div>
              <h3 className="text-3xl font-black text-slate-800 mb-4">Genetic Convergence...</h3>
              <p className="text-slate-500 text-lg max-w-sm font-medium">
                Running multi-objective NSGA-II solver across phytochemical feature sets.
              </p>
            </div>
          )}

          {result && !optimizing && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-8 duration-700">
              {/* Core Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: 'Efficacy', val: `${(result.efficacy * 100).toFixed(0)}%`, icon: CheckCircle2, color: 'text-indigo-600', bg: 'bg-indigo-50' },
                  { label: 'Synergy', val: result.synergy.toFixed(2), icon: BarChart3, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                  { label: 'Toxicity', val: `${(result.toxicity * 100).toFixed(0)}%`, icon: AlertTriangle, color: 'text-rose-500', bg: 'bg-rose-50' },
                  { label: 'Reduction', val: `${result.reduction.toFixed(0)}%`, icon: Info, color: 'text-amber-500', bg: 'bg-amber-50' }
                ].map((item, i) => (
                  <div key={i} className="bg-white p-5 rounded-[28px] border border-slate-200 shadow-sm flex flex-col items-center text-center">
                    <div className={`${item.bg} p-2 rounded-xl mb-3`}>
                      <item.icon className={`w-5 h-5 ${item.color}`} />
                    </div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{item.label}</p>
                    <p className={`text-3xl font-black ${item.color}`}>{item.val}</p>
                  </div>
                ))}
              </div>

              {/* Ratios & Radar Chart */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm">
                  <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-8">Optimal Ratio Vector</h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={compounds.map(c => ({ 
                        name: c.name, 
                        val: (result.ratios[c.id] || 0) * 100 
                      }))}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8'}} />
                        <YAxis axisLine={false} tickLine={false} hide />
                        <Tooltip 
                          cursor={{fill: '#f8fafc'}}
                          contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                        />
                        <Bar dataKey="val" radius={[8, 8, 8, 8]} barSize={40}>
                          {compounds.map((_, index) => (
                            <Cell key={`cell-${index}`} fill={['#6366f1', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'][index % 5]} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm">
                  <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-8">Combination Performance</h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart cx="50%" cy="50%" outerRadius="80%" data={[
                        { subject: 'Efficacy', A: result.efficacy * 100 },
                        { subject: 'Synergy', A: (result.synergy / 2) * 100 },
                        { subject: 'Safety', A: (1 - result.toxicity) * 100 },
                        { subject: 'Stability', A: 85 },
                        { subject: 'ADMET', A: 72 },
                      ]}>
                        <PolarGrid stroke="#f1f5f9" />
                        <PolarAngleAxis dataKey="subject" tick={{fontSize: 10, fill: '#64748b', fontWeight: 600}} />
                        <Radar name="Blend" dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.6} />
                        <Tooltip contentStyle={{ borderRadius: '16px', border: 'none' }} />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Explainability Section */}
              <div className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-8 flex items-center gap-2">
                  <Info className="w-4 h-4" />
                  SHAP Explainability Analysis
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                  <div className="space-y-4">
                    {result.featureImportance.map((feat, i) => (
                      <div key={i} className="space-y-2">
                        <div className="flex justify-between text-[10px] font-bold text-slate-500 uppercase tracking-tighter">
                          <span>{feat.feature}</span>
                          <span className="text-indigo-600">{(feat.value * 100).toFixed(0)}% contribution</span>
                        </div>
                        <div className="w-full bg-slate-50 h-2.5 rounded-full overflow-hidden border border-slate-100">
                          <div 
                            className="bg-indigo-500 h-full rounded-full transition-all duration-1000 shadow-[0_0_10px_rgba(99,102,241,0.3)]" 
                            style={{ width: `${feat.value * 100}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <ScatterChart>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                        <XAxis type="number" dataKey="x" name="Efficacy" domain={[0, 1]} hide />
                        <YAxis type="number" dataKey="y" name="Tox" domain={[0, 1]} hide />
                        <ZAxis type="number" range={[50, 400]} />
                        <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                        <Scatter name="Solutions" data={result.paretoFront} fill="#cbd5e1" shape="circle" />
                        <Scatter name="Selected" data={[{x: result.efficacy, y: result.toxicity}]} fill="#6366f1" />
                      </ScatterChart>
                    </ResponsiveContainer>
                    <p className="text-[10px] text-center text-slate-400 mt-2 font-bold uppercase tracking-widest">Multi-Objective Pareto Optimal Frontier</p>
                  </div>
                </div>
              </div>

              {/* Research Conclusion */}
              <div className="bg-slate-900 rounded-[40px] p-10 text-white shadow-2xl relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-12 opacity-10 group-hover:scale-110 transition-transform duration-1000">
                   <FlaskConical className="w-48 h-48" />
                </div>
                <div className="relative z-10">
                  <div className="bg-indigo-500 w-12 h-1 mb-6"></div>
                  <h3 className="text-3xl font-black mb-6 tracking-tight">Executive Summary</h3>
                  <p className="text-slate-300 text-lg leading-relaxed mb-8 max-w-2xl font-medium">
                    The evolutionary optimization suggests that a blend dominant in <span className="text-white font-bold">{compounds[0].name}</span> and <span className="text-white font-bold">{compounds[1].name}</span> yields the highest therapeutic response. By balancing molecular binding affinities with traditional virya attributes, the engine predicted a <span className="text-emerald-400 font-bold">synergy index of {result.synergy.toFixed(2)}</span>, effectively neutralizing potential metabolic stressors.
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <button className="bg-indigo-600 text-white px-8 py-3 rounded-full font-bold hover:bg-indigo-500 transition-all active:scale-95 shadow-lg shadow-indigo-900/40">
                      Download Dataset (.csv)
                    </button>
                    <button className="border border-slate-700 text-slate-300 px-8 py-3 rounded-full font-bold hover:bg-slate-800 transition-all active:scale-95">
                      Protocol Documentation
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 py-8 text-center">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">
            &copy; 2024 APMOE Research Labs • Systems Pharmacology Unit
          </p>
          <div className="flex gap-6">
             <span className="text-slate-300 text-[10px] font-bold uppercase">v2.4.0-Stable</span>
             <span className="text-slate-300 text-[10px] font-bold uppercase">GenAI Integrated</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
