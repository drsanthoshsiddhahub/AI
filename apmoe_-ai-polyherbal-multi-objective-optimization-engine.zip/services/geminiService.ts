
import { GoogleGenAI, Type } from "@google/genai";
import { Compound } from "../types";

export const predictCombinatorialMetrics = async (
  compounds: Compound[],
  ratios: Record<string, number>
) => {
  // Initialize inside call to ensure process.env.API_KEY is available
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

  const prompt = `
    Analyze this polyherbal combination for medicinal optimization.
    
    Compounds in mixture:
    ${compounds.map(c => `
      - ${c.name}: Ratio=${(ratios[c.id] * 100).toFixed(1)}%, MW=${c.mw}, LogP=${c.logP}, 
        TPSA=${c.tpsa}, Affinity=${c.bindingAffinity}, Rasa=${c.rasa}, Virya=${c.virya}
    `).join('\n')}

    Please return a JSON object with:
    1. efficacy: score from 0 to 1.
    2. toxicity: probability from 0 to 1.
    3. synergy: index value (>1 is synergistic).
    4. toxicityReduction: percentage improvement (0-100).
    5. featureImportance: array of { feature: string, value: number } objects explaining the prediction.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-lite-latest",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            efficacy: { type: Type.NUMBER },
            toxicity: { type: Type.NUMBER },
            synergy: { type: Type.NUMBER },
            toxicityReduction: { type: Type.NUMBER },
            featureImportance: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  feature: { type: Type.STRING },
                  value: { type: Type.NUMBER }
                },
                required: ["feature", "value"]
              }
            }
          },
          required: ["efficacy", "toxicity", "synergy", "featureImportance"]
        }
      }
    });

    const text = response.text || "{}";
    // Sanitize in case of markdown blocks
    const cleanJson = text.replace(/```json/g, "").replace(/```/g, "").trim();
    return JSON.parse(cleanJson);
  } catch (err) {
    console.error("Gemini Prediction Error:", err);
    throw err;
  }
};
