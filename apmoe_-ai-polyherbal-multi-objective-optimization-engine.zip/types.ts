
export interface Compound {
  id: string;
  name: string;
  mw: number; // Molecular Weight
  logP: number;
  tpsa: number;
  hbd: number; // H-bond Donors
  hba: number; // H-bond Acceptors
  bindingAffinity: number;
  rasa: string;
  guna: string;
  virya: string;
  vipaka: string;
}

export interface OptimizationResult {
  ratios: Record<string, number>;
  efficacy: number;
  synergy: number;
  toxicity: number;
  reduction: number;
  paretoFront: ParetoPoint[];
  featureImportance: FeatureImportance[];
}

export interface ParetoPoint {
  x: number; // e.g., Efficacy
  y: number; // e.g., Toxicity
  label: string;
}

export interface FeatureImportance {
  feature: string;
  value: number;
}
