// ============================================================
// Bio-NanoSiddha: The Predictive Pharmacokinetics Explorer
// Main Application Component
// ============================================================

import { useState, useCallback, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import PKChart from './components/PKChart';
import BodyHeatmap from './components/BodyHeatmap';
import {
  WizardState,
  SimulationResult,
  AIPrediction,
  AnubanamType,
  Compartment,
  COMPARTMENT_NAMES,
} from './types';
import { SIDDHA_MEDICINES } from './data/medicines';
import { DEFAULT_COMPARTMENTS, ANUBANAM_PROFILES, PATHOLOGIES } from './data/compartments';
import { runPBPKSimulation, createDefaultParams } from './lib/pbpk-solver';
import { applyAnubanamModifiers, getAnubanamProfile } from './lib/anubanam-logic';
import { generateAIPrediction } from './lib/ai-predictor';
import jsPDF from 'jspdf';

// ── Tab Navigation ──
type TabId = 'simulator' | 'database' | 'about';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('simulator');
  const [wizard, setWizard] = useState<WizardState>({
    step: 1,
    medicineId: 10, // Default: Parpam
    particleSize: 100,
    zetaPotential: -30,
    dose: 50,
    anubanam: 'trikatu',
    pathologyId: 'lung_cancer',
  });

  const [simResult, setSimResult] = useState<SimulationResult | null>(null);
  const [aiPrediction, setAIPrediction] = useState<AIPrediction | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [selectedCompartments, setSelectedCompartments] = useState<number[]>([0, 1, 2, 3, 4, 5]);
  const [autoSim, setAutoSim] = useState(true);
  const [dbSearch, setDbSearch] = useState('');
  const [dbCategoryFilter, setDbCategoryFilter] = useState('all');

  const selectedMedicine = useMemo(
    () => SIDDHA_MEDICINES.find(m => m.id === wizard.medicineId) || SIDDHA_MEDICINES[9],
    [wizard.medicineId]
  );

  const selectedPathology = useMemo(
    () => PATHOLOGIES.find(p => p.id === wizard.pathologyId) || PATHOLOGIES[0],
    [wizard.pathologyId]
  );

  const anubanamProfile = useMemo(
    () => getAnubanamProfile(wizard.anubanam),
    [wizard.anubanam]
  );

  // ── Run Simulation ──
  const runSimulation = useCallback(() => {
    setIsSimulating(true);
    // Use requestAnimationFrame for smooth UI
    requestAnimationFrame(() => {
      try {
        const baseParams = createDefaultParams(
          wizard.dose,
          wizard.particleSize,
          wizard.zetaPotential,
          [...DEFAULT_COMPARTMENTS]
        );
        const modifiedParams = applyAnubanamModifiers(baseParams, wizard.anubanam);
        const result = runPBPKSimulation(
          modifiedParams,
          selectedPathology.organTarget,
          selectedPathology.eprEffect,
          72,
          0.05
        );
        setSimResult(result);
        const prediction = generateAIPrediction(
          modifiedParams,
          result,
          wizard.anubanam,
          selectedPathology.eprEffect
        );
        setAIPrediction(prediction);
      } catch (e) {
        console.error('Simulation error:', e);
      }
      setIsSimulating(false);
    });
  }, [wizard, selectedPathology]);

  // Auto-simulate on parameter change
  useEffect(() => {
    if (autoSim) {
      const timer = setTimeout(runSimulation, 300);
      return () => clearTimeout(timer);
    }
  }, [wizard, autoSim, runSimulation]);

  // ── Current concentrations for heatmap ──
  const currentConcentrations = useMemo(() => {
    if (!simResult) return { blood: 0, liver: 0, lung: 0, spleen: 0, kidney: 0, tumor: 0 };
    // Use concentrations at ~Tmax for the heatmap
    const tmaxIdx = simResult.timePoints.findIndex(t => t >= simResult.Tmax);
    const idx = tmaxIdx >= 0 ? tmaxIdx : Math.floor(simResult.timePoints.length / 4);
    return {
      blood: simResult.concentrations[Compartment.BLOOD]?.[idx] ?? 0,
      liver: simResult.concentrations[Compartment.LIVER]?.[idx] ?? 0,
      lung: simResult.concentrations[Compartment.LUNG]?.[idx] ?? 0,
      spleen: simResult.concentrations[Compartment.SPLEEN]?.[idx] ?? 0,
      kidney: simResult.concentrations[Compartment.KIDNEY]?.[idx] ?? 0,
      tumor: simResult.concentrations[Compartment.TUMOR]?.[idx] ?? 0,
    };
  }, [simResult]);

  const targetOrganKey = useMemo(() => {
    const map: Record<number, string> = {
      [Compartment.BLOOD]: 'blood',
      [Compartment.LIVER]: 'liver',
      [Compartment.LUNG]: 'lung',
      [Compartment.SPLEEN]: 'spleen',
      [Compartment.KIDNEY]: 'kidney',
      [Compartment.TUMOR]: 'tumor',
    };
    return map[selectedPathology.organTarget] || 'tumor';
  }, [selectedPathology]);

  // ── PDF Export ──
  const exportPDF = useCallback(() => {
    if (!simResult || !aiPrediction) return;
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.setTextColor(0, 180, 200);
    doc.text('Bio-NanoSiddha — Scientific Validation Report', 14, 20);
    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Generated: ${new Date().toISOString()}`, 14, 28);
    doc.setDrawColor(0, 180, 200);
    doc.line(14, 32, 196, 32);

    doc.setFontSize(13);
    doc.setTextColor(30, 30, 30);
    doc.text('1. Nanoparticle Fingerprint', 14, 42);
    doc.setFontSize(10);
    doc.setTextColor(60, 60, 60);
    const fpData = [
      `Medicine: ${selectedMedicine.englishName} (${selectedMedicine.tamilName})`,
      `Particle Size: ${wizard.particleSize} nm`,
      `Zeta Potential: ${wizard.zetaPotential} mV`,
      `Dose: ${wizard.dose} mg`,
      `Anubanam: ${anubanamProfile.name}`,
      `Target: ${selectedPathology.name} (${selectedPathology.cellLine})`,
    ];
    fpData.forEach((line, i) => doc.text(line, 20, 50 + i * 6));

    doc.setFontSize(13);
    doc.setTextColor(30, 30, 30);
    doc.text('2. Pharmacokinetic Results', 14, 90);
    doc.setFontSize(10);
    doc.setTextColor(60, 60, 60);
    const pkData = [
      `Cmax: ${simResult.Cmax.toFixed(4)} mg/L`,
      `Tmax: ${simResult.Tmax.toFixed(2)} hours`,
      `AUC(0-72h): ${simResult.AUC.toFixed(2)} mg·hr/L`,
      `Half-life (t½): ${simResult.halfLife.toFixed(2)} hours`,
      `MPS Uptake: ${(simResult.mpsUptakeFraction * 100).toFixed(1)}%`,
      `Tumor Accumulation: ${simResult.tumorAccumulation.toFixed(2)}%`,
      `EPR Efficiency: ${(simResult.eprEfficiency * 100).toFixed(1)}%`,
    ];
    pkData.forEach((line, i) => doc.text(line, 20, 98 + i * 6));

    doc.setFontSize(13);
    doc.setTextColor(30, 30, 30);
    doc.text('3. AI Cross-Attention Analysis', 14, 145);
    doc.setFontSize(10);
    doc.setTextColor(60, 60, 60);
    doc.text(`Prediction Confidence: ${(aiPrediction.confidence * 100).toFixed(1)}%`, 20, 153);
    doc.text(`AI-Predicted Cmax: ${aiPrediction.predictedCmax.toFixed(4)} mg/L`, 20, 159);
    doc.text('Feature Attention Weights:', 20, 167);
    const weights = aiPrediction.attentionWeights;
    doc.text(`  Size: ${(weights.size * 100).toFixed(1)}%  |  Zeta: ${(weights.zeta * 100).toFixed(1)}%  |  Composition: ${(weights.composition * 100).toFixed(1)}%`, 20, 173);
    doc.text(`  Anubanam: ${(weights.anubanam * 100).toFixed(1)}%  |  EPR: ${(weights.epr * 100).toFixed(1)}%`, 20, 179);

    doc.setFontSize(13);
    doc.setTextColor(30, 30, 30);
    doc.text('4. Regulatory Compliance (WHO/FDA)', 14, 195);
    doc.setFontSize(9);
    doc.setTextColor(60, 60, 60);
    aiPrediction.regulatoryFlags.forEach((flag, i) => {
      doc.text(flag, 20, 203 + i * 6);
    });

    doc.setFontSize(13);
    doc.setTextColor(30, 30, 30);
    doc.text('5. FDA Nanomedicine Analogues', 14, 245);
    doc.setFontSize(9);
    doc.setTextColor(60, 60, 60);
    aiPrediction.fdaAnalogues.forEach((a, i) => {
      doc.text(`${a.name} — Similarity: ${(a.similarity * 100).toFixed(1)}%, Cmax: ${a.Cmax} µg/mL`, 20, 253 + i * 6);
    });

    doc.setFontSize(7);
    doc.setTextColor(150, 150, 150);
    doc.text('Bio-NanoSiddha v1.0 | PBPK Model: RK4 ODE Solver | AI: Multi-View Cross-Attention Transformer', 14, 285);
    doc.text('Disclaimer: For research purposes only. Not for clinical decision-making.', 14, 290);
    doc.save('BioNanoSiddha_Report.pdf');
  }, [simResult, aiPrediction, selectedMedicine, wizard, anubanamProfile, selectedPathology]);

  // ── Medicine Database Filters ──
  const filteredMedicines = useMemo(() => {
    return SIDDHA_MEDICINES.filter(m => {
      const matchesSearch = dbSearch === '' ||
        m.englishName.toLowerCase().includes(dbSearch.toLowerCase()) ||
        m.tamilName.includes(dbSearch) ||
        m.therapeuticUse.toLowerCase().includes(dbSearch.toLowerCase());
      const matchesCategory = dbCategoryFilter === 'all' || m.category.toLowerCase().includes(dbCategoryFilter.toLowerCase());
      return matchesSearch && matchesCategory;
    });
  }, [dbSearch, dbCategoryFilter]);

  const categories = useMemo(() => {
    const cats = new Set(SIDDHA_MEDICINES.map(m => m.category));
    return ['all', ...Array.from(cats)];
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-slate-200 overflow-x-hidden">
      {/* ── Header ── */}
      <header className="relative border-b border-slate-800/60 bg-gradient-to-r from-[#0a0e1a] via-[#0d1829] to-[#0a0e1a]">
        <div className="max-w-[1600px] mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-teal-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
                <span className="text-lg">⚗️</span>
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-green-400 border-2 border-[#0a0e1a] animate-pulse" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight">
                <span className="bg-gradient-to-r from-cyan-400 to-teal-300 bg-clip-text text-transparent">Bio-NanoSiddha</span>
              </h1>
              <p className="text-[10px] text-slate-500 tracking-widest uppercase">Predictive Pharmacokinetics Explorer</p>
            </div>
          </div>

          {/* Tabs */}
          <nav className="flex gap-1 bg-slate-800/40 rounded-lg p-1">
            {([
              { id: 'simulator' as TabId, label: '🧪 Simulator', },
              { id: 'database' as TabId, label: '📚 Medicine DB', },
              { id: 'about' as TabId, label: '🔬 About', },
            ]).map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-1.5 text-xs font-medium rounded-md transition-all ${
                  activeTab === tab.id
                    ? 'bg-cyan-600/30 text-cyan-300 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/40'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
              <input
                type="checkbox"
                checked={autoSim}
                onChange={e => setAutoSim(e.target.checked)}
                className="accent-cyan-500"
              />
              Auto-Simulate
            </label>
            {!autoSim && (
              <button
                onClick={runSimulation}
                disabled={isSimulating}
                className="px-4 py-1.5 text-xs font-semibold bg-gradient-to-r from-cyan-600 to-teal-600 text-white rounded-lg hover:from-cyan-500 hover:to-teal-500 disabled:opacity-50 transition-all shadow-lg shadow-cyan-500/20"
              >
                {isSimulating ? '⏳ Solving ODEs...' : '▶ Run Simulation'}
              </button>
            )}
          </div>
        </div>
      </header>

      {/* ── Main Content ── */}
      <main className="max-w-[1600px] mx-auto p-4">
        <AnimatePresence mode="wait">
          {activeTab === 'simulator' && (
            <motion.div
              key="simulator"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <div className="grid grid-cols-12 gap-4">
                {/* ── Left Panel: Wizard ── */}
                <div className="col-span-12 lg:col-span-3 space-y-3">
                  {/* Step 1: Nanoparticle Fingerprint */}
                  <div className="bg-slate-900/60 rounded-xl border border-slate-700/50 p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="w-6 h-6 rounded-full bg-cyan-600/30 text-cyan-400 text-xs flex items-center justify-center font-bold">1</span>
                      <h3 className="text-sm font-semibold text-slate-200">Nanoparticle Fingerprint</h3>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs text-slate-400 mb-1">Medicine</label>
                        <select
                          value={wizard.medicineId ?? ''}
                          onChange={e => {
                            const med = SIDDHA_MEDICINES.find(m => m.id === Number(e.target.value));
                            if (med) {
                              setWizard(w => ({
                                ...w,
                                medicineId: med.id,
                                particleSize: Math.round((med.particleSizeRange[0] + med.particleSizeRange[1]) / 2),
                                zetaPotential: Math.round((med.zetaPotentialRange[0] + med.zetaPotentialRange[1]) / 2),
                              }));
                            }
                          }}
                          className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                        >
                          {SIDDHA_MEDICINES.map(m => (
                            <option key={m.id} value={m.id}>{m.englishName} ({m.tamilName})</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-slate-400">Particle Size</span>
                          <span className="text-cyan-300 font-mono">{wizard.particleSize} nm</span>
                        </div>
                        <input
                          type="range"
                          min={5}
                          max={2000}
                          step={5}
                          value={wizard.particleSize}
                          onChange={e => setWizard(w => ({ ...w, particleSize: Number(e.target.value) }))}
                          className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                        />
                        <div className="flex justify-between text-[10px] text-slate-600 mt-0.5">
                          <span>5 nm</span>
                          <span className="text-cyan-700">optimal: 50-200</span>
                          <span>2000 nm</span>
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-slate-400">Zeta Potential</span>
                          <span className={`font-mono ${Math.abs(wizard.zetaPotential) >= 25 ? 'text-green-400' : Math.abs(wizard.zetaPotential) >= 15 ? 'text-amber-400' : 'text-red-400'}`}>
                            {wizard.zetaPotential} mV
                          </span>
                        </div>
                        <input
                          type="range"
                          min={-50}
                          max={50}
                          step={1}
                          value={wizard.zetaPotential}
                          onChange={e => setWizard(w => ({ ...w, zetaPotential: Number(e.target.value) }))}
                          className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                        />
                        <div className="flex justify-between text-[10px] text-slate-600 mt-0.5">
                          <span>-50 mV</span>
                          <span className="text-green-800">|ζ| ≥ 25: stable</span>
                          <span>+50 mV</span>
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-slate-400">Dose</span>
                          <span className="text-cyan-300 font-mono">{wizard.dose} mg</span>
                        </div>
                        <input
                          type="range"
                          min={1}
                          max={500}
                          step={1}
                          value={wizard.dose}
                          onChange={e => setWizard(w => ({ ...w, dose: Number(e.target.value) }))}
                          className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Step 2: Anubanam Selector */}
                  <div className="bg-slate-900/60 rounded-xl border border-slate-700/50 p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="w-6 h-6 rounded-full bg-amber-600/30 text-amber-400 text-xs flex items-center justify-center font-bold">2</span>
                      <h3 className="text-sm font-semibold text-slate-200">Anubanam (Bio-enhancer)</h3>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {ANUBANAM_PROFILES.map(a => (
                        <button
                          key={a.id}
                          onClick={() => setWizard(w => ({ ...w, anubanam: a.id as AnubanamType }))}
                          className={`px-2 py-2 rounded-lg border text-xs text-left transition-all ${
                            wizard.anubanam === a.id
                              ? 'border-amber-500/50 bg-amber-500/10 text-amber-300'
                              : 'border-slate-700/50 bg-slate-800/40 text-slate-400 hover:border-slate-600'
                          }`}
                        >
                          <span className="text-base mr-1">{a.icon}</span>
                          <span className="font-medium">{a.name.split(' (')[0]}</span>
                          {wizard.anubanam === a.id && a.id !== 'none' && (
                            <div className="mt-1 text-[10px] text-amber-400/70">
                              Ka×{a.kaMultiplier} | Cl×{a.clMultiplier}
                            </div>
                          )}
                        </button>
                      ))}
                    </div>
                    {wizard.anubanam !== 'none' && (
                      <div className="mt-2 p-2 bg-slate-800/40 rounded-lg">
                        <p className="text-[10px] text-slate-400 leading-relaxed">{anubanamProfile.mechanism}</p>
                      </div>
                    )}
                  </div>

                  {/* Step 3: Target Pathology */}
                  <div className="bg-slate-900/60 rounded-xl border border-slate-700/50 p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="w-6 h-6 rounded-full bg-rose-600/30 text-rose-400 text-xs flex items-center justify-center font-bold">3</span>
                      <h3 className="text-sm font-semibold text-slate-200">Target Pathology</h3>
                    </div>
                    <div className="space-y-2">
                      {PATHOLOGIES.map(p => (
                        <button
                          key={p.id}
                          onClick={() => setWizard(w => ({ ...w, pathologyId: p.id }))}
                          className={`w-full px-3 py-2 rounded-lg border text-xs text-left transition-all ${
                            wizard.pathologyId === p.id
                              ? 'border-rose-500/50 bg-rose-500/10 text-rose-300'
                              : 'border-slate-700/50 bg-slate-800/40 text-slate-400 hover:border-slate-600'
                          }`}
                        >
                          <div className="flex justify-between items-center">
                            <span className="font-medium">{p.name}</span>
                            <span className="text-[10px] bg-slate-700/50 px-1.5 py-0.5 rounded">{p.cellLine}</span>
                          </div>
                          {wizard.pathologyId === p.id && (
                            <p className="mt-1 text-[10px] text-rose-400/60">EPR Factor: {p.eprEffect}× | {p.description.slice(0, 80)}...</p>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* IC₅₀ Data */}
                  {selectedMedicine.ic50 && selectedPathology.cellLine !== 'N/A (Systemic)' && (
                    <div className="bg-slate-900/60 rounded-xl border border-emerald-700/30 p-4">
                      <h4 className="text-xs font-semibold text-emerald-400 mb-2">IC₅₀ Data</h4>
                      <div className="space-y-1">
                        {Object.entries(selectedMedicine.ic50).map(([cell, val]) => (
                          <div key={cell} className="flex justify-between text-xs">
                            <span className={cell === selectedPathology.cellLine ? 'text-emerald-300 font-medium' : 'text-slate-500'}>{cell}</span>
                            <span className={cell === selectedPathology.cellLine ? 'text-emerald-300 font-mono' : 'text-slate-500 font-mono'}>{val} μg/mL</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* ── Center Panel: Charts ── */}
                <div className="col-span-12 lg:col-span-6 space-y-4">
                  {/* Compartment toggles */}
                  <div className="flex flex-wrap gap-1.5">
                    {[0, 1, 2, 3, 4, 5, 6].map(c => (
                      <button
                        key={c}
                        onClick={() => {
                          setSelectedCompartments(prev =>
                            prev.includes(c) ? prev.filter(x => x !== c) : [...prev, c]
                          );
                        }}
                        className={`px-2 py-1 text-[10px] rounded-md border transition-all ${
                          selectedCompartments.includes(c)
                            ? 'border-slate-500 bg-slate-700/50 text-slate-200'
                            : 'border-slate-800 bg-slate-900/40 text-slate-600'
                        }`}
                      >
                        <span className={`inline-block w-2 h-2 rounded-full mr-1`}
                          style={{ backgroundColor: ['#ef4444','#f97316','#3b82f6','#a855f7','#22c55e','#f43f5e','#6b7280'][c] }}
                        />
                        {COMPARTMENT_NAMES[c]}
                      </button>
                    ))}
                  </div>

                  {/* PK Chart */}
                  <PKChart result={simResult} selectedCompartments={selectedCompartments} />

                  {/* Key Metrics */}
                  {simResult && (
                    <div className="grid grid-cols-4 gap-2">
                      {[
                        { label: 'Cmax', value: `${simResult.Cmax.toFixed(3)}`, unit: 'mg/L', color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
                        { label: 'Tmax', value: `${simResult.Tmax.toFixed(2)}`, unit: 'hr', color: 'text-amber-400', bg: 'bg-amber-500/10' },
                        { label: 't½', value: `${simResult.halfLife.toFixed(1)}`, unit: 'hr', color: 'text-purple-400', bg: 'bg-purple-500/10' },
                        { label: 'AUC₀₋₇₂', value: `${simResult.AUC.toFixed(1)}`, unit: 'mg·hr/L', color: 'text-green-400', bg: 'bg-green-500/10' },
                      ].map(m => (
                        <motion.div
                          key={m.label}
                          className={`${m.bg} border border-slate-700/30 rounded-xl p-3 text-center`}
                          initial={{ scale: 0.95, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          transition={{ duration: 0.2 }}
                        >
                          <p className="text-[10px] text-slate-500 uppercase tracking-wider">{m.label}</p>
                          <p className={`text-lg font-bold font-mono ${m.color}`}>{m.value}</p>
                          <p className="text-[9px] text-slate-600">{m.unit}</p>
                        </motion.div>
                      ))}
                    </div>
                  )}

                  {/* Distribution Bars */}
                  {simResult && (
                    <div className="bg-slate-900/60 rounded-xl border border-slate-700/50 p-4">
                      <h3 className="text-sm font-semibold text-slate-300 mb-3">Drug Distribution at T<sub>max</sub></h3>
                      <div className="space-y-2">
                        {[
                          { label: 'MPS Uptake', val: simResult.mpsUptakeFraction, color: 'bg-orange-500' },
                          { label: 'Renal Clearance', val: simResult.renalClearanceFraction, color: 'bg-blue-500' },
                          { label: 'Tumor Accumulation', val: simResult.tumorAccumulation / 100, color: 'bg-rose-500' },
                          { label: 'EPR Efficiency', val: simResult.eprEfficiency, color: 'bg-emerald-500' },
                        ].map(b => (
                          <div key={b.label}>
                            <div className="flex justify-between text-xs mb-0.5">
                              <span className="text-slate-400">{b.label}</span>
                              <span className="text-slate-300 font-mono">{(b.val * 100).toFixed(1)}%</span>
                            </div>
                            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                              <motion.div
                                className={`h-full rounded-full ${b.color}`}
                                initial={{ width: 0 }}
                                animate={{ width: `${Math.min(100, b.val * 100)}%` }}
                                transition={{ duration: 0.5, ease: 'easeOut' }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* ── Right Panel: Heatmap + AI ── */}
                <div className="col-span-12 lg:col-span-3 space-y-3">
                  {/* Body Heatmap */}
                  <div className="bg-slate-900/60 rounded-xl border border-slate-700/50 p-4">
                    <h3 className="text-sm font-semibold text-slate-300 mb-2">Tissue Distribution Heatmap</h3>
                    <BodyHeatmap concentrations={currentConcentrations} targetOrgan={targetOrganKey} />
                  </div>

                  {/* AI Prediction Panel */}
                  {aiPrediction && (
                    <div className="bg-slate-900/60 rounded-xl border border-indigo-700/30 p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <span className="text-base">🤖</span>
                        <h3 className="text-sm font-semibold text-indigo-300">Cross-Attention AI</h3>
                        <span className="ml-auto text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full">
                          {(aiPrediction.confidence * 100).toFixed(0)}% conf.
                        </span>
                      </div>

                      {/* Attention Weights */}
                      <div className="mb-3">
                        <p className="text-[10px] text-slate-500 mb-1.5 uppercase tracking-wider">Feature Attention</p>
                        <div className="space-y-1">
                          {Object.entries(aiPrediction.attentionWeights).map(([key, val]) => (
                            <div key={key} className="flex items-center gap-2">
                              <span className="text-[10px] text-slate-400 w-20 capitalize">{key}</span>
                              <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                <motion.div
                                  className="h-full bg-gradient-to-r from-indigo-500 to-violet-500 rounded-full"
                                  initial={{ width: 0 }}
                                  animate={{ width: `${val * 100}%` }}
                                  transition={{ duration: 0.5, delay: 0.1 }}
                                />
                              </div>
                              <span className="text-[10px] text-indigo-300 font-mono w-10 text-right">{(val * 100).toFixed(0)}%</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* FDA Analogues */}
                      <div className="mb-3">
                        <p className="text-[10px] text-slate-500 mb-1.5 uppercase tracking-wider">FDA NP Analogues</p>
                        <div className="space-y-1.5">
                          {aiPrediction.fdaAnalogues.map((a, i) => (
                            <div key={i} className="flex items-center justify-between text-[10px] bg-slate-800/40 px-2 py-1.5 rounded-lg">
                              <span className="text-slate-300 truncate max-w-[140px]">{a.name}</span>
                              <span className="text-indigo-300 font-mono">{(a.similarity * 100).toFixed(0)}%</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Regulatory Flags */}
                      <div>
                        <p className="text-[10px] text-slate-500 mb-1.5 uppercase tracking-wider">Regulatory Status</p>
                        <div className="space-y-1">
                          {aiPrediction.regulatoryFlags.map((flag, i) => (
                            <p key={i} className="text-[10px] text-slate-400 leading-relaxed">{flag}</p>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Export */}
                  {simResult && (
                    <button
                      onClick={exportPDF}
                      className="w-full px-4 py-2.5 text-xs font-semibold bg-gradient-to-r from-emerald-700 to-teal-700 text-emerald-100 rounded-xl hover:from-emerald-600 hover:to-teal-600 transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/20"
                    >
                      📄 Export Scientific Report (PDF)
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'database' && (
            <motion.div
              key="database"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <div className="bg-slate-900/60 rounded-xl border border-slate-700/50 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-xl font-bold text-slate-200">32 Internal Medicines of Siddha</h2>
                    <p className="text-sm text-slate-500">Complete pharmacokinetic database with nanoparticle characterization</p>
                  </div>
                  <div className="flex gap-3">
                    <input
                      type="text"
                      placeholder="Search medicines..."
                      value={dbSearch}
                      onChange={e => setDbSearch(e.target.value)}
                      className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-cyan-500 w-56"
                    />
                    <select
                      value={dbCategoryFilter}
                      onChange={e => setDbCategoryFilter(e.target.value)}
                      className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                    >
                      {categories.map(c => (
                        <option key={c} value={c}>{c === 'all' ? 'All Categories' : c}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-slate-700">
                        {['#', 'Tamil Name', 'English Name', 'Category', 'Shelf Life', 'Composition', 'Size (nm)', 'ζ (mV)', 'IC₅₀ (A549)', 'Use'].map(h => (
                          <th key={h} className="px-3 py-2 text-left text-slate-400 font-semibold uppercase tracking-wider text-[10px]">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {filteredMedicines.map(m => (
                        <tr
                          key={m.id}
                          className="border-b border-slate-800/50 hover:bg-slate-800/30 cursor-pointer transition-colors"
                          onClick={() => {
                            setWizard(w => ({
                              ...w,
                              medicineId: m.id,
                              particleSize: Math.round((m.particleSizeRange[0] + m.particleSizeRange[1]) / 2),
                              zetaPotential: Math.round((m.zetaPotentialRange[0] + m.zetaPotentialRange[1]) / 2),
                            }));
                            setActiveTab('simulator');
                          }}
                        >
                          <td className="px-3 py-2 text-slate-500 font-mono">{m.id}</td>
                          <td className="px-3 py-2 text-amber-300">{m.tamilName}</td>
                          <td className="px-3 py-2 text-slate-200 font-medium">{m.englishName}</td>
                          <td className="px-3 py-2"><span className="bg-slate-700/50 px-1.5 py-0.5 rounded text-[10px]">{m.category}</span></td>
                          <td className="px-3 py-2 text-slate-400">{m.shelfLife}</td>
                          <td className="px-3 py-2 text-slate-400 max-w-[120px] truncate">{m.primaryComposition.join(', ')}</td>
                          <td className="px-3 py-2 text-cyan-300 font-mono">{m.particleSizeRange[0]}–{m.particleSizeRange[1]}</td>
                          <td className="px-3 py-2 text-cyan-300 font-mono">{m.zetaPotentialRange[0]} to {m.zetaPotentialRange[1]}</td>
                          <td className="px-3 py-2 text-emerald-300 font-mono">{m.ic50?.['A549'] ? `${m.ic50['A549']} μg/mL` : '—'}</td>
                          <td className="px-3 py-2 text-slate-400 max-w-[150px] truncate">{m.therapeuticUse}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="mt-4 text-[10px] text-slate-600 text-center">Click any row to load medicine into the simulator</p>
              </div>
            </motion.div>
          )}

          {activeTab === 'about' && (
            <motion.div
              key="about"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <div className="max-w-4xl mx-auto space-y-6">
                <div className="bg-slate-900/60 rounded-xl border border-slate-700/50 p-8">
                  <h2 className="text-2xl font-bold text-cyan-400 mb-4">About Bio-NanoSiddha</h2>
                  <p className="text-slate-300 text-sm leading-relaxed mb-6">
                    Bio-NanoSiddha is a computational pharmacology platform that bridges ancient Siddha metallic nanomedicine 
                    (Parpams and Chendoorams) with modern Physiologically Based Pharmacokinetic (PBPK) modeling and 
                    AI-powered prediction.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-slate-800/40 rounded-xl p-5">
                      <h3 className="text-sm font-bold text-cyan-300 mb-3">🧮 Mathematical Core</h3>
                      <div className="space-y-2 text-xs text-slate-400">
                        <p><strong className="text-slate-300">PBPK ODE System:</strong> 8-compartment model (Blood, Liver, Lung, Spleen, Kidney, Tumor, Rest, Gut) solved using 4th-order Runge-Kutta integration.</p>
                        <p className="font-mono text-cyan-400/80 bg-slate-900/60 p-2 rounded">Vᵢ · dCᵢ/dt = Qᵢ · (C_blood − Cᵢ/Pᵢ) − R_MPS − R_clearance</p>
                        <p><strong className="text-slate-300">MPS Uptake:</strong> Hill-type kinetics modeling macrophage sequestration:</p>
                        <p className="font-mono text-cyan-400/80 bg-slate-900/60 p-2 rounded">R_MPS = K_TRESmax · Cⁿ / (K_TRES50ⁿ + Cⁿ) · f_MPS · f_size</p>
                        <p><strong className="text-slate-300">Nernst-Planck Transport:</strong> Electrostatic correction for charged NP transport across glycocalyx.</p>
                        <p className="font-mono text-cyan-400/80 bg-slate-900/60 p-2 rounded">ψ = (z·F·ΔV)/(R·T); correction = ψ/(eᵠ − 1)</p>
                      </div>
                    </div>

                    <div className="bg-slate-800/40 rounded-xl p-5">
                      <h3 className="text-sm font-bold text-indigo-300 mb-3">🤖 AI Architecture</h3>
                      <div className="space-y-2 text-xs text-slate-400">
                        <p><strong className="text-slate-300">Multi-View Cross-Attention:</strong> Transformer-based model combining batch-specific NP attributes with prior knowledge from FDA-approved nanomedicines.</p>
                        <p><strong className="text-slate-300">View 1 (Query):</strong> Particle size, zeta potential, dose, Ka, Cl — the experimental nanoparticle fingerprint.</p>
                        <p><strong className="text-slate-300">View 2 (Key/Value):</strong> Reference PK data from Doxil®, Abraxane®, Feraheme®, NanoTherm®, Onivyde®, and Hensify®.</p>
                        <p className="font-mono text-indigo-400/80 bg-slate-900/60 p-2 rounded">Attention(Q,K,V) = softmax(QKᵀ/√d_k) · V</p>
                        <p><strong className="text-slate-300">Output:</strong> Confidence-weighted PK predictions refined by analogous FDA data.</p>
                      </div>
                    </div>

                    <div className="bg-slate-800/40 rounded-xl p-5">
                      <h3 className="text-sm font-bold text-amber-300 mb-3">🌿 Anubanam Logic</h3>
                      <div className="space-y-2 text-xs text-slate-400">
                        <p><strong className="text-slate-300">Trikatu (Piperine):</strong> CYP3A4 + P-glycoprotein inhibition → Ka ×1.5, Cl ×0.7, bioavailability ↑35%</p>
                        <p><strong className="text-slate-300">Ghee (Lipid Corona):</strong> Lymphatic transport bypass → reduced first-pass, MPS evasion via lipid coating</p>
                        <p><strong className="text-slate-300">Milk (Casein Corona):</strong> Protein corona stabilization → improved colloidal stability in GI tract</p>
                        <p><strong className="text-slate-300">Honey (Enzymatic):</strong> Mucosal absorption enhancement via hygroscopic + enzymatic action</p>
                      </div>
                    </div>

                    <div className="bg-slate-800/40 rounded-xl p-5">
                      <h3 className="text-sm font-bold text-rose-300 mb-3">🏥 Clinical Relevance</h3>
                      <div className="space-y-2 text-xs text-slate-400">
                        <p><strong className="text-slate-300">EPR Effect:</strong> Size-dependent Enhanced Permeability and Retention for tumor targeting (optimal: 50-200 nm).</p>
                        <p><strong className="text-slate-300">IC₅₀ Validation:</strong> Standardized cytotoxicity data for A549, MCF-7, HepG2, and HeLa cell lines.</p>
                        <p><strong className="text-slate-300">Regulatory Mapping:</strong> WHO/FDA compliance markers for nanoparticle characterization standards.</p>
                        <p className="mt-2 text-rose-400 italic">⚠️ Research platform only. Not for clinical decision-making.</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/60 rounded-xl border border-slate-700/50 p-6">
                  <h3 className="text-lg font-bold text-slate-200 mb-3">Technology Stack</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {[
                      { name: 'React + Vite', desc: 'UI Framework', icon: '⚛️' },
                      { name: 'Tailwind CSS', desc: 'Styling', icon: '🎨' },
                      { name: 'Framer Motion', desc: 'Animations', icon: '✨' },
                      { name: 'Recharts', desc: 'Data Visualization', icon: '📊' },
                      { name: 'RK4 ODE Solver', desc: 'Mathematical Core', icon: '🧮' },
                      { name: 'Cross-Attention', desc: 'AI Predictions', icon: '🤖' },
                      { name: 'jsPDF', desc: 'Report Generation', icon: '📄' },
                      { name: 'TypeScript', desc: 'Type Safety', icon: '📘' },
                    ].map(t => (
                      <div key={t.name} className="bg-slate-800/40 rounded-lg p-3 text-center">
                        <span className="text-2xl">{t.icon}</span>
                        <p className="text-xs font-medium text-slate-200 mt-1">{t.name}</p>
                        <p className="text-[10px] text-slate-500">{t.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/60 mt-8 py-4">
        <div className="max-w-[1600px] mx-auto px-4 flex items-center justify-between text-[10px] text-slate-600">
          <span>Bio-NanoSiddha v1.0 — Predictive Pharmacokinetics Explorer</span>
          <span>PBPK: RK4 Solver | AI: Multi-View Cross-Attention | 32 Siddha Medicines</span>
          <span>For research purposes only</span>
        </div>
      </footer>
    </div>
  );
}
