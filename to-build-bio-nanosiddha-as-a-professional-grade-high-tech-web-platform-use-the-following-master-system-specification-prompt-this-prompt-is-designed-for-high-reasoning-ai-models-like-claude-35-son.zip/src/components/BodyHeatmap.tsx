// ============================================================
// Bio-NanoSiddha: Human Body Tissue Heatmap
// SVG-based human silhouette showing nanoparticle accumulation
// ============================================================

import { motion } from 'framer-motion';

interface BodyHeatmapProps {
  concentrations: {
    blood: number;
    liver: number;
    lung: number;
    spleen: number;
    kidney: number;
    tumor: number;
  };
  targetOrgan: string;
}

function intensityToColor(value: number): string {
  // Map 0-1 to a cyan/green/yellow/red gradient
  const clamped = Math.max(0, Math.min(1, value));
  if (clamped < 0.25) {
    const t = clamped / 0.25;
    return `rgba(0, ${Math.round(100 + 155 * t)}, ${Math.round(255 * (1 - t))}, ${0.3 + clamped * 2})`;
  } else if (clamped < 0.5) {
    const t = (clamped - 0.25) / 0.25;
    return `rgba(${Math.round(255 * t)}, 255, 0, ${0.5 + clamped})`;
  } else if (clamped < 0.75) {
    const t = (clamped - 0.5) / 0.25;
    return `rgba(255, ${Math.round(255 * (1 - t))}, 0, ${0.6 + clamped * 0.4})`;
  } else {
    const t = (clamped - 0.75) / 0.25;
    return `rgba(255, ${Math.round(50 * (1 - t))}, ${Math.round(50 * t)}, ${0.8 + clamped * 0.2})`;
  }
}

function glowFilter(id: string, intensity: number): React.JSX.Element {
  const blur = 3 + intensity * 12;
  return (
    <filter id={id} x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur in="SourceGraphic" stdDeviation={blur} />
    </filter>
  );
}

export default function BodyHeatmap({ concentrations, targetOrgan }: BodyHeatmapProps) {
  const maxConc = Math.max(
    concentrations.blood,
    concentrations.liver,
    concentrations.lung,
    concentrations.spleen,
    concentrations.kidney,
    concentrations.tumor,
    0.001
  );

  const norm = (v: number) => v / maxConc;

  const organs = [
    { key: 'lung', label: 'Lungs', x: 150, y: 115, w: 60, h: 45, val: norm(concentrations.lung) },
    { key: 'liver', label: 'Liver', x: 120, y: 170, w: 40, h: 30, val: norm(concentrations.liver) },
    { key: 'spleen', label: 'Spleen', x: 190, y: 175, w: 22, h: 18, val: norm(concentrations.spleen) },
    { key: 'kidney', label: 'Kidneys', x: 145, y: 200, w: 45, h: 22, val: norm(concentrations.kidney) },
    { key: 'tumor', label: 'Tumor', x: 170, y: 140, w: 16, h: 16, val: norm(concentrations.tumor) },
    { key: 'blood', label: 'Blood', x: 155, y: 85, w: 30, h: 25, val: norm(concentrations.blood) },
  ];

  return (
    <div className="relative">
      <svg viewBox="0 0 300 420" className="w-full h-full max-h-[420px]" style={{ filter: 'drop-shadow(0 0 10px rgba(0,255,200,0.1))' }}>
        <defs>
          {organs.map(o => glowFilter(`glow-${o.key}`, o.val))}
          <linearGradient id="bodyGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#1a2744" />
            <stop offset="100%" stopColor="#0d1b2a" />
          </linearGradient>
          <filter id="body-shadow">
            <feGaussianBlur in="SourceAlpha" stdDeviation="2" />
            <feOffset dx="0" dy="2" />
            <feComposite in2="SourceAlpha" operator="out" />
            <feColorMatrix values="0 0 0 0 0  0 0 0 0 0.5  0 0 0 0 0.8  0 0 0 0.3 0" />
            <feBlend in2="SourceGraphic" />
          </filter>
        </defs>

        {/* Human body silhouette */}
        <g filter="url(#body-shadow)">
          {/* Head */}
          <ellipse cx="155" cy="40" rx="22" ry="26" fill="#1e3a5f" stroke="#2d5a8e" strokeWidth="1" />
          {/* Neck */}
          <rect x="147" y="64" width="16" height="14" fill="#1e3a5f" stroke="#2d5a8e" strokeWidth="0.5" />
          {/* Torso */}
          <path d="M 115 78 Q 110 78 108 90 L 105 180 Q 104 210 115 235 L 120 240 L 190 240 L 195 235 Q 206 210 205 180 L 202 90 Q 200 78 195 78 Z"
            fill="#1e3a5f" stroke="#2d5a8e" strokeWidth="1" />
          {/* Left arm */}
          <path d="M 108 85 Q 85 90 75 140 Q 70 165 72 190 Q 73 200 78 205 Q 83 200 85 195 Q 90 165 95 140 Q 100 115 108 100"
            fill="#1e3a5f" stroke="#2d5a8e" strokeWidth="1" />
          {/* Right arm */}
          <path d="M 202 85 Q 225 90 235 140 Q 240 165 238 190 Q 237 200 232 205 Q 227 200 225 195 Q 220 165 215 140 Q 210 115 202 100"
            fill="#1e3a5f" stroke="#2d5a8e" strokeWidth="1" />
          {/* Left leg */}
          <path d="M 120 240 L 115 320 Q 113 350 115 380 Q 116 395 110 410 L 125 410 Q 130 395 130 380 L 138 320 L 145 240"
            fill="#1e3a5f" stroke="#2d5a8e" strokeWidth="1" />
          {/* Right leg */}
          <path d="M 165 240 L 172 320 Q 175 350 175 380 Q 175 395 180 410 L 195 410 Q 190 395 190 380 L 192 320 L 190 240"
            fill="#1e3a5f" stroke="#2d5a8e" strokeWidth="1" />
        </g>

        {/* Organ highlights */}
        {organs.map(organ => (
          <g key={organ.key}>
            {/* Glow effect */}
            {organ.val > 0.05 && (
              <motion.ellipse
                cx={organ.x}
                cy={organ.y}
                rx={organ.w / 2 + organ.val * 10}
                ry={organ.h / 2 + organ.val * 8}
                fill={intensityToColor(organ.val)}
                filter={`url(#glow-${organ.key})`}
                initial={{ opacity: 0 }}
                animate={{ opacity: organ.val * 0.7 }}
                transition={{ duration: 0.5 }}
              />
            )}
            {/* Organ shape */}
            <motion.ellipse
              cx={organ.x}
              cy={organ.y}
              rx={organ.w / 2}
              ry={organ.h / 2}
              fill={intensityToColor(organ.val)}
              stroke={organ.key === targetOrgan ? '#00ffcc' : '#4a90d9'}
              strokeWidth={organ.key === targetOrgan ? 2 : 0.5}
              strokeDasharray={organ.key === targetOrgan ? '4 2' : 'none'}
              initial={{ opacity: 0.3 }}
              animate={{ 
                opacity: 0.3 + organ.val * 0.7,
                scale: 1 + organ.val * 0.05,
              }}
              transition={{ duration: 0.3 }}
            />
            {/* Label */}
            <text
              x={organ.x + organ.w / 2 + 8}
              y={organ.y + 4}
              fill="#94a3b8"
              fontSize="8"
              fontFamily="monospace"
            >
              {organ.label}
            </text>
            {/* Concentration value */}
            {organ.val > 0.01 && (
              <text
                x={organ.x + organ.w / 2 + 8}
                y={organ.y + 14}
                fill="#67e8f9"
                fontSize="7"
                fontFamily="monospace"
              >
                {(organ.val * maxConc).toFixed(2)} mg/L
              </text>
            )}
          </g>
        ))}

        {/* Legend */}
        <g transform="translate(10, 350)">
          <text x="0" y="0" fill="#94a3b8" fontSize="8" fontWeight="bold">Concentration Scale</text>
          <defs>
            <linearGradient id="legendGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="rgba(0,200,255,0.3)" />
              <stop offset="33%" stopColor="rgba(0,255,100,0.6)" />
              <stop offset="66%" stopColor="rgba(255,255,0,0.8)" />
              <stop offset="100%" stopColor="rgba(255,50,0,1)" />
            </linearGradient>
          </defs>
          <rect x="0" y="8" width="80" height="8" rx="2" fill="url(#legendGrad)" />
          <text x="0" y="26" fill="#64748b" fontSize="6">Low</text>
          <text x="65" y="26" fill="#64748b" fontSize="6">High</text>
        </g>

        {/* Target indicator */}
        <g transform="translate(10, 390)">
          <line x1="0" y1="2" x2="12" y2="2" stroke="#00ffcc" strokeWidth="2" strokeDasharray="4 2" />
          <text x="16" y="5" fill="#00ffcc" fontSize="7">Target Organ</text>
        </g>
      </svg>
    </div>
  );
}
