// ============================================================
// Bio-NanoSiddha: Interactive Pharmacokinetic Curve Chart
// Dynamic Cₚ vs. Time graph with Cmax and Tmax markers
// ============================================================

import { useMemo } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceDot,
  ReferenceLine,
} from 'recharts';
import { SimulationResult, COMPARTMENT_NAMES } from '../types';

interface PKChartProps {
  result: SimulationResult | null;
  selectedCompartments: number[];
}

const COMPARTMENT_COLORS = [
  '#ef4444', // Blood - Red
  '#f97316', // Liver - Orange
  '#3b82f6', // Lung - Blue
  '#a855f7', // Spleen - Purple
  '#22c55e', // Kidney - Green
  '#f43f5e', // Tumor - Rose
  '#6b7280', // Rest - Gray
  '#eab308', // Gut - Yellow
];

export default function PKChart({ result, selectedCompartments }: PKChartProps) {
  const chartData = useMemo(() => {
    if (!result) return [];
    return result.timePoints.map((t, idx) => {
      const point: Record<string, number> = { time: parseFloat(t.toFixed(2)) };
      selectedCompartments.forEach(c => {
        point[`c${c}`] = parseFloat((result.concentrations[c]?.[idx] ?? 0).toFixed(4));
      });
      return point;
    });
  }, [result, selectedCompartments]);

  if (!result) {
    return (
      <div className="flex items-center justify-center h-80 bg-slate-900/50 rounded-xl border border-slate-700/50">
        <p className="text-slate-500 text-sm">Run simulation to see PK curves</p>
      </div>
    );
  }

  return (
    <div className="bg-slate-900/60 rounded-xl border border-slate-700/50 p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-cyan-400 tracking-wide">
          Cₚ vs. Time — Pharmacokinetic Profile
        </h3>
        <div className="flex gap-3 text-xs">
          <span className="text-slate-400">
            C<sub>max</sub>: <span className="text-cyan-300 font-mono">{result.Cmax.toFixed(3)} mg/L</span>
          </span>
          <span className="text-slate-400">
            T<sub>max</sub>: <span className="text-amber-300 font-mono">{result.Tmax.toFixed(2)} hr</span>
          </span>
          <span className="text-slate-400">
            AUC: <span className="text-green-300 font-mono">{result.AUC.toFixed(2)} mg·hr/L</span>
          </span>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={320}>
        <LineChart data={chartData} margin={{ top: 10, right: 30, left: 10, bottom: 10 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
          <XAxis
            dataKey="time"
            stroke="#64748b"
            tick={{ fontSize: 11, fill: '#94a3b8' }}
            label={{ value: 'Time (hours)', position: 'insideBottom', offset: -5, fill: '#94a3b8', fontSize: 11 }}
          />
          <YAxis
            stroke="#64748b"
            tick={{ fontSize: 11, fill: '#94a3b8' }}
            label={{ value: 'Concentration (mg/L)', angle: -90, position: 'insideLeft', offset: 10, fill: '#94a3b8', fontSize: 11 }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#0f172a',
              border: '1px solid #334155',
              borderRadius: '8px',
              fontSize: '11px',
            }}
            labelStyle={{ color: '#94a3b8' }}
            labelFormatter={(v) => `t = ${v} hr`}
            formatter={(value: unknown, name: unknown) => {
              const idx = parseInt(String(name).replace('c', ''));
              return [`${Number(value).toFixed(4)} mg/L`, COMPARTMENT_NAMES[idx]];
            }}
          />
          <Legend
            formatter={(value: string) => {
              const idx = parseInt(value.replace('c', ''));
              return <span style={{ color: COMPARTMENT_COLORS[idx], fontSize: '11px' }}>{COMPARTMENT_NAMES[idx]}</span>;
            }}
          />

          {/* Cmax reference line */}
          <ReferenceLine
            y={result.Cmax}
            stroke="#22d3ee"
            strokeDasharray="5 5"
            strokeWidth={1}
          />

          {/* Tmax reference line */}
          <ReferenceLine
            x={parseFloat(result.Tmax.toFixed(2))}
            stroke="#fbbf24"
            strokeDasharray="5 5"
            strokeWidth={1}
          />

          {/* Cmax point */}
          {selectedCompartments.includes(0) && (
            <ReferenceDot
              x={parseFloat(result.Tmax.toFixed(2))}
              y={parseFloat(result.Cmax.toFixed(4))}
              r={5}
              fill="#22d3ee"
              stroke="#fff"
              strokeWidth={2}
            />
          )}

          {selectedCompartments.map(c => (
            <Line
              key={c}
              type="monotone"
              dataKey={`c${c}`}
              stroke={COMPARTMENT_COLORS[c]}
              strokeWidth={c === 0 ? 2.5 : 1.5}
              dot={false}
              activeDot={{ r: 4, stroke: '#fff', strokeWidth: 1 }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
