// ============================================================
// Bio-NanoSiddha: PBPK Compartment Parameters
// Physiologically based values for a 70 kg adult human
// ============================================================

import { CompartmentParams, AnubanamProfile, Pathology, Compartment } from '../types';

/** 
 * Standard physiological parameters for PBPK compartments.
 * References: Brown et al. (1997), ICRP Publication 89
 */
export const DEFAULT_COMPARTMENTS: CompartmentParams[] = [
  {
    name: 'Blood (Plasma)',
    volume: 5.0,        // L
    bloodFlow: 0,        // L/hr (reference compartment)
    partitionCoeff: 1.0, // reference
    mpsActivity: 0.05,   // minimal circulating macrophages
  },
  {
    name: 'Liver',
    volume: 1.8,         // L
    bloodFlow: 90.0,     // L/hr (~25% cardiac output)
    partitionCoeff: 8.0, // high uptake for nanoparticles (Kupffer cells)
    mpsActivity: 0.85,   // dominant MPS organ
  },
  {
    name: 'Lung',
    volume: 0.5,         // L
    bloodFlow: 300.0,    // L/hr (entire cardiac output passes through)
    partitionCoeff: 3.0,
    mpsActivity: 0.30,   // alveolar macrophages
  },
  {
    name: 'Spleen',
    volume: 0.15,        // L
    bloodFlow: 12.0,     // L/hr
    partitionCoeff: 10.0,// high sequestration
    mpsActivity: 0.90,   // highest MPS density
  },
  {
    name: 'Kidney',
    volume: 0.31,        // L
    bloodFlow: 72.0,     // L/hr (~20% cardiac output)
    partitionCoeff: 4.0,
    mpsActivity: 0.15,   // mesangial cells
  },
  {
    name: 'Tumor',
    volume: 0.05,        // L (estimated for ~5cm tumor)
    bloodFlow: 3.0,      // L/hr (typically poorly perfused)
    partitionCoeff: 2.0, // EPR-dependent
    mpsActivity: 0.10,   // TAMs (tumor-associated macrophages)
  },
  {
    name: 'Rest of Body',
    volume: 55.0,        // L (remaining tissue mass)
    bloodFlow: 120.0,    // L/hr
    partitionCoeff: 1.5,
    mpsActivity: 0.02,
  },
  {
    name: 'Gut (Absorption)',
    volume: 1.0,         // L
    bloodFlow: 60.0,     // L/hr
    partitionCoeff: 2.0,
    mpsActivity: 0.20,   // gut-associated lymphoid tissue
  },
];

/**
 * Anubanam (bio-enhancer) profiles with PK modifiers.
 * Based on traditional Siddha pharmacology and modern pharmacokinetic studies.
 */
export const ANUBANAM_PROFILES: AnubanamProfile[] = [
  {
    id: 'honey',
    name: 'Honey (Thein)',
    tamilName: 'தேன்',
    kaMultiplier: 1.2,
    clMultiplier: 0.95,
    lymphaticBoost: 0.1,
    bioavailabilityBoost: 0.1,
    mechanism: 'Enhances mucosal absorption via hygroscopic properties. Contains natural enzymes (diastase, invertase) that facilitate particle dissolution. Increases GI transit time for improved absorption.',
    icon: '🍯',
  },
  {
    id: 'ghee',
    name: 'Ghee (Nei)',
    tamilName: 'நெய்',
    kaMultiplier: 1.1,
    clMultiplier: 0.85,
    lymphaticBoost: 0.5,
    bioavailabilityBoost: 0.2,
    mechanism: 'Lipid-based carrier promoting lymphatic transport (bypasses first-pass hepatic metabolism). Medium-chain fatty acids form lipid corona around nanoparticles, enhancing cellular uptake via lipid raft-mediated endocytosis.',
    icon: '🧈',
  },
  {
    id: 'milk',
    name: 'Milk (Paal)',
    tamilName: 'பால்',
    kaMultiplier: 1.05,
    clMultiplier: 0.9,
    lymphaticBoost: 0.3,
    bioavailabilityBoost: 0.15,
    mechanism: 'Casein protein corona formation increases colloidal stability. Lipid micelles serve as nanocarriers. Calcium ions may modulate tight junction permeability for paracellular transport.',
    icon: '🥛',
  },
  {
    id: 'trikatu',
    name: 'Trikatu (Thirikadugu)',
    tamilName: 'திரிகடுகு',
    kaMultiplier: 1.5,
    clMultiplier: 0.7,
    lymphaticBoost: 0.15,
    bioavailabilityBoost: 0.35,
    mechanism: 'Piperine inhibits CYP3A4 and P-glycoprotein (P-gp) efflux pump → ↑ oral bioavailability by 30-200%. Capsaicin enhances thermogenesis and GI blood flow. Gingerol provides anti-inflammatory gastroprotection.',
    icon: '🌶️',
  },
  {
    id: 'warm_water',
    name: 'Warm Water (Venneer)',
    tamilName: 'வெந்நீர்',
    kaMultiplier: 1.0,
    clMultiplier: 1.0,
    lymphaticBoost: 0.0,
    bioavailabilityBoost: 0.05,
    mechanism: 'Standard vehicle. Warm temperature increases GI blood flow marginally. Provides adequate dissolution medium without significant PK modification.',
    icon: '💧',
  },
  {
    id: 'none',
    name: 'None (Direct)',
    tamilName: 'நேரடி',
    kaMultiplier: 1.0,
    clMultiplier: 1.0,
    lymphaticBoost: 0.0,
    bioavailabilityBoost: 0.0,
    mechanism: 'No adjuvant. Baseline pharmacokinetic profile without enhancement.',
    icon: '⚪',
  },
];

/**
 * Target pathologies with EPR effect parameters.
 */
export const PATHOLOGIES: Pathology[] = [
  {
    id: 'lung_cancer',
    name: 'Lung Adenocarcinoma',
    cellLine: 'A549',
    organTarget: Compartment.LUNG,
    eprEffect: 2.5,
    description: 'Non-small cell lung cancer. High vascularity with fenestrated endothelium (100-800nm pore cutoff). EPR effect is significant for particles < 200nm.',
  },
  {
    id: 'breast_cancer',
    name: 'Breast Carcinoma',
    cellLine: 'MCF-7',
    organTarget: Compartment.TUMOR,
    eprEffect: 2.0,
    description: 'ER+ breast cancer. Moderate EPR effect. Nanoparticle accumulation depends on tumor perfusion and lymphatic drainage.',
  },
  {
    id: 'liver_cancer',
    name: 'Hepatocellular Carcinoma',
    cellLine: 'HepG2',
    organTarget: Compartment.LIVER,
    eprEffect: 3.0,
    description: 'Primary liver cancer. Liver naturally accumulates nanoparticles via Kupffer cells. Dual targeting via passive (EPR) and active (MPS) mechanisms.',
  },
  {
    id: 'cervical_cancer',
    name: 'Cervical Carcinoma',
    cellLine: 'HeLa',
    organTarget: Compartment.TUMOR,
    eprEffect: 1.8,
    description: 'Aggressive cervical cancer. Moderate EPR effect with dense tumor microenvironment requiring smaller particle sizes.',
  },
  {
    id: 'anemia',
    name: 'Iron-Deficiency Anemia',
    cellLine: 'N/A (Systemic)',
    organTarget: Compartment.BLOOD,
    eprEffect: 1.0,
    description: 'Systemic condition. Target is circulating blood compartment. Iron oxide nanoparticles (Mandooram) provide sustained iron release.',
  },
  {
    id: 'kidney_disease',
    name: 'Chronic Kidney Disease',
    cellLine: 'HK-2',
    organTarget: Compartment.KIDNEY,
    eprEffect: 1.5,
    description: 'Renal tubular epithelial targeting. Particles < 8nm undergo renal filtration; 20-100nm optimal for tubular targeting.',
  },
];
