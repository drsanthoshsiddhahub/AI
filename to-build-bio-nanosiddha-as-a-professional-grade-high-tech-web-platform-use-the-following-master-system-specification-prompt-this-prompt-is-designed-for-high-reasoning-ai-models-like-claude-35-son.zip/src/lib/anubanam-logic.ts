// ============================================================
// Bio-NanoSiddha: Anubanam (Bio-enhancer) Logic Gate System
//
// Implements pharmacokinetic parameter modification based on
// traditional Siddha adjuvant (Anubanam) selection.
//
// Each Anubanam modifies the PBPK parameters through specific
// biochemical mechanisms validated in modern pharmacology.
// ============================================================

import { PBPKParams, AnubanamType } from '../types';
import { ANUBANAM_PROFILES } from '../data/compartments';

/**
 * Apply Anubanam modifications to PBPK parameters.
 * 
 * This implements a logic-gate system where each adjuvant
 * modifies specific PK parameters based on its mechanism:
 * 
 * ┌─────────────────────────────────────────────────────────────┐
 * │ Anubanam    │ Ka ×   │ Cl ×   │ Lymph ↑  │ Mechanism       │
 * ├─────────────┼────────┼────────┼──────────┼─────────────────┤
 * │ Trikatu     │ 1.5    │ 0.7    │ +0.15    │ CYP3A4/P-gp inh│
 * │ Ghee        │ 1.1    │ 0.85   │ +0.50    │ Lipid corona    │
 * │ Milk        │ 1.05   │ 0.9    │ +0.30    │ Casein coating  │
 * │ Honey       │ 1.2    │ 0.95   │ +0.10    │ Mucosal enhance │
 * │ Warm Water  │ 1.0    │ 1.0    │ +0.00    │ Standard vehicle│
 * │ None        │ 1.0    │ 1.0    │ +0.00    │ No modification │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * @param params Base PBPK parameters
 * @param anubanam Selected Anubanam type
 * @returns Modified PBPK parameters
 */
export function applyAnubanamModifiers(params: PBPKParams, anubanam: AnubanamType): PBPKParams {
  const profile = ANUBANAM_PROFILES.find(p => p.id === anubanam);
  if (!profile || anubanam === 'none') return { ...params };
  
  const modified = { ...params };
  
  // ── Absorption Rate Modification ──
  // Ka' = Ka × multiplier
  modified.Ka = params.Ka * profile.kaMultiplier;
  
  // ── Clearance Modification ──
  // Cl' = Cl × multiplier
  // For Trikatu: CYP3A4 inhibition by piperine reduces hepatic clearance
  // For Ghee: First-pass bypass via lymphatic routing
  modified.Cl = params.Cl * profile.clMultiplier;
  
  // ── Lymphatic Transport Enhancement ──
  // λ' = λ + boost
  // Ghee provides the strongest lymphatic boost due to lipid corona formation
  modified.lymphaticCoeff = params.lymphaticCoeff + profile.lymphaticBoost;
  
  // ── Bioavailability Enhancement ──
  // F' = min(0.95, F + boost)
  modified.bioavailability = Math.min(0.95, params.bioavailability + profile.bioavailabilityBoost);
  
  // ── Specific Mechanism Modifiers ──
  switch (anubanam) {
    case 'trikatu':
      // Piperine-specific: Also reduces MPS uptake by modulating
      // NF-κB pathway → reduced macrophage activation
      modified.KtresMax = params.KtresMax * 0.8;
      
      // P-gp inhibition increases net absorption
      // Additional GI blood flow from capsaicin
      modified.compartments = params.compartments.map((c, i) => {
        if (i === 7) { // Gut
          return { ...c, bloodFlow: c.bloodFlow * 1.3 };
        }
        return c;
      });
      break;
      
    case 'ghee':
      // Lipid corona formation:
      // - Increases partition coefficients (lipophilic partitioning)
      // - Reduces opsonization → reduced MPS uptake
      modified.KtresMax = params.KtresMax * 0.6; // lipid coating reduces phagocytosis
      modified.compartments = params.compartments.map(c => ({
        ...c,
        partitionCoeff: c.partitionCoeff * 1.2, // lipid-enhanced tissue distribution
      }));
      break;
      
    case 'milk':
      // Casein protein corona:
      // - Stabilizes nanoparticles (Smoluchowski stability theory)
      // - Moderate lipid content for lymphatic routing
      modified.KtresMax = params.KtresMax * 0.75;
      break;
      
    case 'honey':
      // Enzymatic enhancement:
      // - Diastase and invertase aid particle dissolution
      // - Hygroscopic properties improve mucosal contact time
      // - Antimicrobial effect protects drug integrity in gut
      modified.compartments = params.compartments.map((c, i) => {
        if (i === 7) { // Gut - increased contact time
          return { ...c, volume: c.volume * 1.1 };
        }
        return c;
      });
      break;
  }
  
  return modified;
}

/**
 * Get the Anubanam profile for display purposes.
 */
export function getAnubanamProfile(anubanam: AnubanamType) {
  return ANUBANAM_PROFILES.find(p => p.id === anubanam) || ANUBANAM_PROFILES[5]; // default to 'none'
}
