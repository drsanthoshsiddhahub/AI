// ============================================================
// Bio-NanoSiddha: PBPK ODE Solver
// 
// Implements a Physiologically Based Pharmacokinetic model
// using 4th-order Runge-Kutta (RK4) numerical integration.
//
// Mass Balance Equation for each compartment i:
//   V_i · dC_i/dt = Q_i · (C_blood − C_i/P_i) − R_MPS_i − R_clearance_i
//
// Where:
//   V_i   = tissue volume (L)
//   C_i   = concentration in tissue i (mg/L)
//   Q_i   = blood flow to tissue i (L/hr)
//   P_i   = tissue:blood partition coefficient
//   R_MPS = MPS uptake rate (Hill kinetics)
//   R_clearance = renal/hepatic clearance
// ============================================================

import { PBPKParams, SimulationResult, Compartment, NUM_COMPARTMENTS, CompartmentParams } from '../types';

/** State vector: concentrations in each compartment */
type StateVector = number[];

/**
 * Nernst-Planck correction factor for charged particle transport
 * across the glycocalyx barrier.
 * 
 * ψ = (z·F·ΔV) / (R·T)
 * correction = ψ / (exp(ψ) − 1)
 * 
 * This models electrostatic interactions between charged nanoparticles
 * (characterized by Zeta Potential) and the negatively charged glycocalyx.
 */
function nernstPlanckCorrection(zetaPotential: number, glycocalyxCharge: number, ionicStrength: number): number {
  const R = 8.314;      // J/(mol·K)
  const T = 310.15;     // K (37°C body temperature)
  const F = 96485;      // C/mol (Faraday constant)
  const z = zetaPotential < 0 ? -1 : 1;  // effective charge sign
  
  // Debye length (nm) — characterizes electric double layer thickness
  const debyeLength = 0.304 / Math.sqrt(ionicStrength); // nm at 37°C
  
  // Potential difference at glycocalyx surface
  const deltaV = (zetaPotential - glycocalyxCharge) * 1e-3; // Convert mV to V
  
  // Dimensionless potential
  const psi = (z * F * deltaV) / (R * T);
  
  // Correction factor (avoids division by zero)
  if (Math.abs(psi) < 1e-6) return 1.0;
  const correction = psi / (Math.exp(psi) - 1);
  
  // Modulate by Debye length effect (ionic screening)
  const screeningFactor = Math.exp(-1 / debyeLength);
  
  return Math.max(0.1, Math.min(3.0, correction * (1 + screeningFactor)));
}

/**
 * Size-dependent MPS (Mononuclear Phagocyte System) uptake modifier.
 * Particles 100-300nm are most efficiently phagocytosed.
 * Very small (<20nm) and very large (>1000nm) particles have reduced uptake.
 */
function sizeDepMPSFactor(particleSize: number): number {
  // Optimal phagocytosis at ~200nm
  const optimalSize = 200;
  const sigma = 150;
  return Math.exp(-0.5 * Math.pow((particleSize - optimalSize) / sigma, 2));
}

/**
 * EPR (Enhanced Permeability and Retention) effect modifier.
 * Depends on particle size — optimal for 50-200nm particles.
 */
function eprSizeFactor(particleSize: number): number {
  if (particleSize < 10) return 0.2;   // too small, rapid clearance
  if (particleSize < 50) return 0.7;
  if (particleSize <= 200) return 1.0; // optimal EPR range
  if (particleSize <= 400) return 0.6;
  return 0.2;                          // too large, poor extravasation
}

/**
 * MPS uptake rate using Hill-like kinetics:
 *   R_MPS = K_TRESmax · C^n / (K_TRES50^n + C^n) · f_MPS · f_size
 * 
 * @param C Concentration in compartment (mg/L)
 * @param KtresMax Maximum uptake rate (hr⁻¹)
 * @param Ktres50 Half-saturation concentration (mg/L)
 * @param hillCoeff Hill coefficient (cooperativity)
 * @param mpsActivity MPS activity factor for this compartment
 * @param particleSize Particle size in nm
 */
function mpsUptakeRate(
  C: number,
  KtresMax: number,
  Ktres50: number,
  hillCoeff: number,
  mpsActivity: number,
  particleSize: number
): number {
  if (C <= 0) return 0;
  const Cn = Math.pow(C, hillCoeff);
  const K50n = Math.pow(Ktres50, hillCoeff);
  const hillRate = KtresMax * Cn / (K50n + Cn);
  return hillRate * mpsActivity * sizeDepMPSFactor(particleSize);
}

/**
 * Compute the right-hand side of the ODE system (dC/dt for each compartment).
 */
function computeDerivatives(
  state: StateVector,
  params: PBPKParams,
  nernstCorrection: number,
  eprFactor: number,
  tumorTargetCompartment: number
): StateVector {
  const dCdt: number[] = new Array(NUM_COMPARTMENTS).fill(0);
  const { compartments, Ka, Cl, KtresMax, Ktres50, hillCoeff, lymphaticCoeff, particleSize } = params;
  
  const Cblood = state[Compartment.BLOOD];
  const Cgut = state[Compartment.GUT];
  
  // ── Gut (Absorption) Compartment ──
  // dC_gut/dt = -Ka · C_gut
  dCdt[Compartment.GUT] = -Ka * Cgut;
  
  // ── Blood (Central) Compartment ──
  // Receives absorbed drug, loses to all peripheral compartments and clearance
  let bloodInflow = Ka * Cgut * compartments[Compartment.GUT].volume; // absorption from gut
  let bloodOutflow = 0;
  
  // Clearance (renal + hepatic combined)
  const clearanceRate = Cl * Cblood;
  
  // Lymphatic return to blood
  const lymphReturn = lymphaticCoeff * state[Compartment.GUT] * 0.1;
  
  // Sum flows from/to peripheral compartments
  for (let i = 1; i < NUM_COMPARTMENTS - 1; i++) { // skip blood (0) and gut (7)
    const comp = compartments[i];
    const Ci = state[i];
    
    // Nernst-Planck corrected blood flow
    let effectiveFlow = comp.bloodFlow * nernstCorrection;
    
    // EPR effect for tumor compartment
    if (i === tumorTargetCompartment || i === Compartment.TUMOR) {
      effectiveFlow *= eprFactor;
    }
    
    // Net flow: Q_i · (C_blood − C_i / P_i)
    const netFlux = effectiveFlow * (Cblood - Ci / comp.partitionCoeff);
    
    bloodOutflow += Math.max(0, netFlux);
    bloodInflow += Math.max(0, -netFlux);
  }
  
  dCdt[Compartment.BLOOD] = (bloodInflow - bloodOutflow - clearanceRate + lymphReturn) / compartments[Compartment.BLOOD].volume;
  
  // ── Peripheral Compartments ──
  for (let i = 1; i < NUM_COMPARTMENTS - 1; i++) {
    const comp = compartments[i];
    const Ci = state[i];
    
    let effectiveFlow = comp.bloodFlow * nernstCorrection;
    if (i === tumorTargetCompartment || i === Compartment.TUMOR) {
      effectiveFlow *= eprFactor;
    }
    
    // Distribution: Q_i · (C_blood − C_i / P_i)
    const distribution = effectiveFlow * (Cblood - Ci / comp.partitionCoeff);
    
    // MPS uptake (sequestration)
    const mpsRate = mpsUptakeRate(Ci, KtresMax, Ktres50, hillCoeff, comp.mpsActivity, particleSize);
    const mpsRemoval = mpsRate * Ci * comp.volume;
    
    // Lymphatic uptake (primarily in liver and gut)
    let lymphUptake = 0;
    if (i === Compartment.LIVER || i === Compartment.GUT) {
      lymphUptake = lymphaticCoeff * Ci * comp.volume;
    }
    
    dCdt[i] = (distribution - mpsRemoval - lymphUptake) / comp.volume;
  }
  
  return dCdt;
}

/**
 * 4th-order Runge-Kutta (RK4) integrator for the PBPK ODE system.
 * 
 * This is chosen over simpler methods (Euler) for its excellent
 * accuracy-to-computational-cost ratio, suitable for moderately stiff systems.
 */
function rk4Step(
  state: StateVector,
  dt: number,
  params: PBPKParams,
  nernstCorrection: number,
  eprFactor: number,
  tumorTarget: number
): StateVector {
  const n = state.length;
  
  // k1 = f(t, y)
  const k1 = computeDerivatives(state, params, nernstCorrection, eprFactor, tumorTarget);
  
  // k2 = f(t + dt/2, y + dt/2 · k1)
  const s2: number[] = new Array(n);
  for (let i = 0; i < n; i++) s2[i] = state[i] + 0.5 * dt * k1[i];
  const k2 = computeDerivatives(s2, params, nernstCorrection, eprFactor, tumorTarget);
  
  // k3 = f(t + dt/2, y + dt/2 · k2)
  const s3: number[] = new Array(n);
  for (let i = 0; i < n; i++) s3[i] = state[i] + 0.5 * dt * k2[i];
  const k3 = computeDerivatives(s3, params, nernstCorrection, eprFactor, tumorTarget);
  
  // k4 = f(t + dt, y + dt · k3)
  const s4: number[] = new Array(n);
  for (let i = 0; i < n; i++) s4[i] = state[i] + dt * k3[i];
  const k4 = computeDerivatives(s4, params, nernstCorrection, eprFactor, tumorTarget);
  
  // y(t+dt) = y(t) + (dt/6) · (k1 + 2k2 + 2k3 + k4)
  const newState: number[] = new Array(n);
  for (let i = 0; i < n; i++) {
    newState[i] = state[i] + (dt / 6) * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]);
    // Enforce non-negativity (concentrations cannot be negative)
    if (newState[i] < 0) newState[i] = 0;
  }
  
  return newState;
}

/**
 * Run the full PBPK simulation.
 * 
 * @param params PBPK parameters (with Anubanam modifications already applied)
 * @param tumorTarget Which compartment is the primary target
 * @param eprMultiplier EPR effect multiplier for the target pathology
 * @param totalTime Simulation duration in hours
 * @param dt Time step in hours
 */
export function runPBPKSimulation(
  params: PBPKParams,
  tumorTarget: number,
  eprMultiplier: number,
  totalTime: number = 72,
  dt: number = 0.05
): SimulationResult {
  const numSteps = Math.ceil(totalTime / dt);
  const recordInterval = Math.max(1, Math.floor(numSteps / 500)); // ~500 data points
  
  // Compute correction factors
  const nernstCorrection = nernstPlanckCorrection(
    params.zetaPotential,
    params.glycocalyxCharge,
    params.ionicStrength
  );
  const eprFactor = eprMultiplier * eprSizeFactor(params.particleSize);
  
  // Initial state: all drug in gut compartment
  let state: number[] = new Array(NUM_COMPARTMENTS).fill(0);
  state[Compartment.GUT] = (params.dose * params.bioavailability) / params.compartments[Compartment.GUT].volume;
  
  // Storage arrays
  const timePoints: number[] = [];
  const concentrations: number[][] = Array.from({ length: NUM_COMPARTMENTS }, () => []);
  
  // Track MPS and clearance
  let totalMPSUptake = 0;
  let totalClearance = 0;
  
  // Record initial state
  timePoints.push(0);
  for (let c = 0; c < NUM_COMPARTMENTS; c++) {
    concentrations[c].push(state[c]);
  }
  
  // ── Time Integration Loop ──
  for (let step = 1; step <= numSteps; step++) {
    const prevState = state;
    state = rk4Step(state, dt, params, nernstCorrection, eprFactor, tumorTarget);
    
    // Accumulate MPS and clearance
    for (let c = 0; c < NUM_COMPARTMENTS; c++) {
      const mpsRate = mpsUptakeRate(
        prevState[c],
        params.KtresMax, params.Ktres50, params.hillCoeff,
        params.compartments[c].mpsActivity,
        params.particleSize
      );
      totalMPSUptake += mpsRate * prevState[c] * params.compartments[c].volume * dt;
    }
    totalClearance += params.Cl * prevState[Compartment.BLOOD] * dt;
    
    // Record at intervals
    if (step % recordInterval === 0 || step === numSteps) {
      const t = step * dt;
      timePoints.push(t);
      for (let c = 0; c < NUM_COMPARTMENTS; c++) {
        concentrations[c].push(state[c]);
      }
    }
  }
  
  // ── Compute PK Metrics ──
  const bloodConc = concentrations[Compartment.BLOOD];
  let Cmax = 0;
  let TmaxIdx = 0;
  let AUC = 0;
  
  for (let i = 0; i < bloodConc.length; i++) {
    if (bloodConc[i] > Cmax) {
      Cmax = bloodConc[i];
      TmaxIdx = i;
    }
    // Trapezoidal rule for AUC
    if (i > 0) {
      const dt_auc = timePoints[i] - timePoints[i - 1];
      AUC += 0.5 * (bloodConc[i] + bloodConc[i - 1]) * dt_auc;
    }
  }
  
  const Tmax = timePoints[TmaxIdx];
  
  // Half-life: find time where C = Cmax/2 after Tmax
  let halfLife = totalTime;
  for (let i = TmaxIdx; i < bloodConc.length; i++) {
    if (bloodConc[i] <= Cmax / 2) {
      halfLife = timePoints[i] - Tmax;
      break;
    }
  }
  
  // Tumor accumulation (% of dose)
  const tumorConc = concentrations[tumorTarget] || concentrations[Compartment.TUMOR];
  const tumorMaxConc = Math.max(...tumorConc);
  const tumorAccumulation = (tumorMaxConc * params.compartments[tumorTarget].volume) / params.dose * 100;
  
  // Total dose for fraction calculations
  const totalDose = params.dose * params.bioavailability;
  
  return {
    timePoints,
    concentrations,
    Cmax,
    Tmax,
    AUC,
    halfLife,
    mpsUptakeFraction: Math.min(0.95, totalMPSUptake / totalDose),
    renalClearanceFraction: Math.min(0.95, totalClearance / totalDose),
    tumorAccumulation: Math.min(50, tumorAccumulation),
    eprEfficiency: eprFactor / eprMultiplier,
  };
}

/**
 * Create default PBPK parameters from nanoparticle fingerprint.
 */
export function createDefaultParams(
  dose: number,
  particleSize: number,
  zetaPotential: number,
  compartments: CompartmentParams[]
): PBPKParams {
  // Size-dependent absorption rate
  // Smaller particles absorb faster
  const sizeKa = 0.5 + (500 - Math.min(particleSize, 500)) / 500 * 1.5;
  
  // Size-dependent clearance
  // Very small particles: rapid renal clearance
  // Moderate: slower clearance
  const sizeCl = particleSize < 10 ? 5.0 :
                 particleSize < 50 ? 2.0 :
                 particleSize < 200 ? 0.8 :
                 particleSize < 500 ? 0.5 : 0.3;
  
  return {
    dose,
    particleSize,
    zetaPotential,
    Ka: sizeKa,
    Cl: sizeCl,
    bioavailability: 0.4 + Math.abs(zetaPotential) / 100, // higher zeta → better stability → better bioavail
    KtresMax: 2.0,         // max MPS uptake rate
    Ktres50: 5.0,          // half-saturation at 5 mg/L
    hillCoeff: 2.0,        // cooperative uptake
    lymphaticCoeff: 0.05,  // baseline lymphatic transport
    ionicStrength: 0.15,   // physiological ionic strength (0.15 M NaCl)
    glycocalyxCharge: -20, // mV (negatively charged glycocalyx)
    compartments,
  };
}
