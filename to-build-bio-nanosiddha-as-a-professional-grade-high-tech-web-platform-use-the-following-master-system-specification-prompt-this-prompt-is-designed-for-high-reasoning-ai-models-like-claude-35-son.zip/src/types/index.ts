// ============================================================
// Bio-NanoSiddha: Type Definitions
// ============================================================

/** Compartment indices for the PBPK model */
export enum Compartment {
  BLOOD = 0,
  LIVER = 1,
  LUNG = 2,
  SPLEEN = 3,
  KIDNEY = 4,
  TUMOR = 5,
  REST = 6,
  GUT = 7, // absorption compartment
}

export const COMPARTMENT_NAMES = [
  'Blood (Plasma)',
  'Liver',
  'Lung',
  'Spleen',
  'Kidney',
  'Tumor',
  'Rest of Body',
  'Gut (Absorption)',
] as const;

export const NUM_COMPARTMENTS = 8;

/** Physiological parameters for each compartment */
export interface CompartmentParams {
  name: string;
  volume: number;       // L
  bloodFlow: number;    // L/hr
  partitionCoeff: number; // tissue:blood partition coefficient
  mpsActivity: number;  // MPS uptake activity (0–1 scale)
}

/** Full PBPK model parameters */
export interface PBPKParams {
  dose: number;             // mg
  particleSize: number;     // nm (hydrodynamic diameter)
  zetaPotential: number;    // mV
  Ka: number;               // absorption rate constant (hr⁻¹)
  Cl: number;               // systemic clearance (L/hr)
  bioavailability: number;  // fraction (0–1)
  // MPS (Mononuclear Phagocyte System) parameters – Hill kinetics
  KtresMax: number;         // max uptake rate (hr⁻¹)
  Ktres50: number;          // half-saturation concentration (mg/L)
  hillCoeff: number;        // Hill coefficient
  // Lymphatic transport
  lymphaticCoeff: number;   // lymphatic transport coefficient (hr⁻¹)
  // Nernst-Planck corrections
  ionicStrength: number;    // mol/L
  glycocalyxCharge: number; // mV (surface charge of glycocalyx)
  // Compartment parameters
  compartments: CompartmentParams[];
}

/** Anubanam (bio-enhancer) types */
export type AnubanamType = 'honey' | 'ghee' | 'milk' | 'trikatu' | 'warm_water' | 'none';

export interface AnubanamProfile {
  id: AnubanamType;
  name: string;
  tamilName: string;
  kaMultiplier: number;       // absorption rate modifier
  clMultiplier: number;       // clearance modifier
  lymphaticBoost: number;     // lymphatic transport boost
  bioavailabilityBoost: number;
  mechanism: string;
  icon: string;
}

/** Target pathology */
export interface Pathology {
  id: string;
  name: string;
  cellLine: string;
  organTarget: Compartment;
  eprEffect: number;          // Enhanced Permeability & Retention factor
  description: string;
}

/** Siddha medicine entry */
export interface SiddhaMedicine {
  id: number;
  tamilName: string;
  englishName: string;
  category: string;
  shelfLife: string;
  primaryComposition: string[];
  particleSizeRange: [number, number]; // nm
  zetaPotentialRange: [number, number]; // mV
  ic50?: Record<string, number>;       // IC₅₀ values per cell line (μg/mL)
  therapeuticUse: string;
  dosageForm: string;
}

/** Simulation results */
export interface SimulationResult {
  timePoints: number[];
  concentrations: number[][];  // [compartment][timeIndex]
  Cmax: number;
  Tmax: number;
  AUC: number;
  halfLife: number;
  mpsUptakeFraction: number;
  renalClearanceFraction: number;
  tumorAccumulation: number;
  eprEfficiency: number;
}

/** Wizard state */
export interface WizardState {
  step: number;
  // Step 1: Nanoparticle Fingerprint
  medicineId: number | null;
  particleSize: number;
  zetaPotential: number;
  dose: number;
  // Step 2: Anubanam
  anubanam: AnubanamType;
  // Step 3: Target
  pathologyId: string;
}

/** AI Prediction output */
export interface AIPrediction {
  predictedCmax: number;
  predictedTmax: number;
  confidence: number;
  attentionWeights: {
    size: number;
    zeta: number;
    composition: number;
    anubanam: number;
    epr: number;
  };
  fdaAnalogues: {
    name: string;
    similarity: number;
    Cmax: number;
  }[];
  regulatoryFlags: string[];
}

export interface SimulationConfig {
  params: PBPKParams;
  anubanam: AnubanamType;
  pathology: Pathology;
  medicine: SiddhaMedicine;
}
